AGENDA DE COMPROMISSOS — PACOTE DE PUBLICAÇÃO

1. index.html
   Visão executiva somente leitura. Este é o arquivo recomendado para publicação online.

2. gestao_local.html
   Ferramenta completa de gestão. Mantenha privada. Ela salva dados no navegador e não deve ser publicada em link aberto.

ATUALIZAÇÃO DA VISÃO PÚBLICA
- Atualize a gestão normalmente.
- Use a função “Exportar visão executiva” na ferramenta de gestão.
- Substitua o index.html publicado pelo novo HTML executivo exportado.

IMPORTANTE
- Hospedagem estática não sincroniza automaticamente o localStorage da gestão.
- Para atualização automática entre gestão e visão pública será necessário um backend/base central (SharePoint/Lists, banco de dados, etc.).
